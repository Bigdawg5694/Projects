using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpeedupEffectMonitor : MonoBehaviour
{

    #region Fields

    // make a timer field for this class
    Timer speedupEffect;

    // make a bool for whether the speedup effect is active
    bool speedupActive = false;

    // make an int for the speedup factor found through our config files
    int speedupFactor = 2;

    #endregion

    #region Properties

    /// <summary>
    /// gets whether our speedup effect is active or not
    /// </summary>
    public bool SpeedupActive
    {
        get { return speedupActive; }
    }

    /// <summary>
    /// gets the speedup factor
    /// </summary>
    public int SpeedupFactor
    {
        get { return speedupFactor; }
    }

    /// <summary>
    /// gets the remaining time on the timer
    /// </summary>
    public float EffectRemainingTime
    {
        get { return speedupEffect.RemainingTime; }
    }

    #endregion

    #region Methods

    // Start is called before the first frame update
    void Start()
    {
        // use event manager to add SpeedupEffectTimer as a listener
        // to SpeedupEffectEvent
        EventManager.AddSpeedupEffectEventListener(SpeedupEffect);

        // makes a timer for the speedupEffect
        speedupEffect = gameObject.GetComponent<Timer>();

        // this adds the event listener for the effect timer
        // when it is done
        speedupEffect.AddTimerFinishedEventListener(SpeedupEffectTimerFinished);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    /// <summary>
    /// this is a timer for the Speedup Effect,
    /// and it will keep track of how long the effect
    /// has left
    /// </summary>
    /// <param name="duration">timer duration</param>
    /// <param name="speedup">speedup factor</param>
    void SpeedupEffect(float duration, int speedup)
    {
        if (!speedupActive)
        {
            // set the duratiopin of our timer
            speedupEffect.Duration = duration;

            // run the timer
            speedupEffect.Run();

            // set speedup effect to true
            speedupActive = true;

            // sets the speedupfactor to the float provided in the event
            speedupFactor = speedup;
        }
        else
        {
            // adds time if effect is active
            speedupEffect.AddTime(duration);
        }

    }

    /// <summary>
    /// This is the listener for when the timer is finished
    /// </summary>
    void SpeedupEffectTimerFinished()
    {
        // checks to see if the timer is finished
        if (speedupEffect.Finished)
        {
            // stops the timer
            speedupEffect.Stop();

            // sets active bool to false
            speedupActive = false;
        }
    }

    #endregion
}
