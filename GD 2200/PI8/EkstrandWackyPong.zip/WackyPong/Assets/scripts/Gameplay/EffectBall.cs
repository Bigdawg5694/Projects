using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class EffectBall : Ball
{
    #region Fields

    // setting a field for freezer effect activated
    FreezerEffectActivatedEvent freezeActive;

    // setting a field for speedup effect activated
    SpeedupEventActivatedEvent speedupActive;

    #endregion

    #region public Methods

    /// <summary>
    /// method the effect ball will run when spawned in
    /// </summary>
    new public virtual void Start()
    {
        // call the parent start method for movement
        base.Start();

        // setting all events and timers for freeze effect
        // if the balltype is freeze
        if (type == BallType.Freeze)
        {
            // make a new event for freezer activated
            freezeActive = new FreezerEffectActivatedEvent();

            // add this script as an event invoker for freeze
            EventManager.AddFreezeEffectEventInvoker(this);
        }

        // setting all events and timers to speedup effect
        // if the balltype is speedup
        if (type == BallType.SpeedUp)
        {
            // make a new event for speedup activated
            speedupActive = new SpeedupEventActivatedEvent();

            // add this script as an event invoker for speedup
            EventManager.AddSpeedupEffectEventInvoker(this);
        }
    }

    /// <summary>
    /// method for adding a listener for the freeze activated event
    /// </summary>
    /// <param name="handler"></param>
    public void AddFreezeEffectListener(UnityAction<ScreenSide, float> handler)
    {
        freezeActive.AddListener(handler);
    }

    /// <summary>
    /// adds a listener to the speedup activated event
    /// </summary>
    /// <param name="handler"></param>
    public void AddSpeedupEffectListener(UnityAction<float, int> handler)
    {
        speedupActive.AddListener(handler);
    }

    /// <summary>
    /// initiates the balls effect when colliding with a paddle
    /// </summary>
    /// <param name="col">collision of effectball</param>
    public void OnCollisionEnter2D(Collision2D col)
    {
        // checks if type is freeze
        if (type == BallType.Freeze)
        {
            // checks which side collided with te effect ball
            if (col.gameObject.tag == "LeftPaddle")
            {
                // invoke freezeactive event for right paddle
                freezeActive.Invoke(ScreenSide.Right, ConfigurationUtils.FreezeDuration);

                // invoke ball died event
                ballDiedEvent.Invoke();

                // destroy self
                Destroy(gameObject);
            }
            if (col.gameObject.tag == "RightPaddle")
            {
                // invoke freezeactive event for left paddle
                freezeActive.Invoke(ScreenSide.Left, ConfigurationUtils.FreezeDuration);

                // invoke ball died event
                ballDiedEvent.Invoke();

                // destroy self
                Destroy(gameObject);
            }
        }

        //checks if type is speedup
        if (type == BallType.SpeedUp)
        {
            if (col.gameObject.tag == "LeftPaddle" || col.gameObject.tag == "RightPaddle")
            {
                // invoke speedup event
                speedupActive.Invoke(ConfigurationUtils.SpeedupDuration,
                    ConfigurationUtils.SpeedupFactor);

                // invoke balldied event
                ballDiedEvent.Invoke();

                //Destroy self
                Destroy(gameObject);
            }
        }
    }

    #endregion
}
