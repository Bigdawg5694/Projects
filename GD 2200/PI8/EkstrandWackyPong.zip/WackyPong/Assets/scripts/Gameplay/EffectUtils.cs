using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class EffectUtils
{
    #region Fields

    // makes a SpeedupEffectMonitor object
    static SpeedupEffectMonitor speedupEffect;

    #endregion

    #region Properties

    /// <summary>
    /// gets whether speedup is active or not
    /// </summary>
    public static bool SpeedupActive
    {
        get { return speedupEffect.SpeedupActive; }
    }

    /// <summary>
    /// gets the speedup factor for the balls
    /// </summary>
    public static int SpeedupFactor
    {
        get { return speedupEffect.SpeedupFactor; }
    }

    /// <summary>
    /// gets the remaining time on the speedup timer
    /// </summary>
    public static float RemainingTime
    {
        get { return speedupEffect.EffectRemainingTime; }
    }

    #endregion

    #region Methods

    /// <summary>
    /// initalize our effects utils
    /// </summary>
    public static void Initialize()
    {
        speedupEffect = new SpeedupEffectMonitor();
    }

    #endregion
}
