﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// An enumeration of the screen sides
/// </summary>
public enum ScreenSide
{
    Left,
    Right
}
