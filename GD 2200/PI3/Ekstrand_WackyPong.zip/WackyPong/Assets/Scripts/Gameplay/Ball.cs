﻿using System.Collections;
using System.Collections.Generic;
using UnityEditor.Experimental.GraphView;
using UnityEngine;

/// <summary>
/// A ball
/// </summary>
public class Ball : MonoBehaviour
{
	//sets our rigidbody2d and vector2 for our ball
	Rigidbody2D rb2d;
	Vector2 moveDirection = new Vector2 (0, 0);
	ScreenSide screenSide;

	Timer deathTimer;
	Timer spawnTimer;
	BallSpawner ballSpawn;
	float spawnTime = 1;

	HUD hud;
	/// <summary>
	/// this is where we set the property of the ball
	/// and what it returns
	/// </summary>
	public int Hits
	{
		get { return ConfigurationUtils.StandardBall; }
	}

	/// <summary>
	/// this is where we access the property of the
	/// balls total time in game
	/// </summary>
	public float Lifetime
	{
		get { return ConfigurationUtils.BallLifetime; }
	}

	/// <summary>
	/// Start is called before the first frame update
	/// </summary>
	public void Start()
	{
		//this gets all components from the game object
		rb2d = GetComponent<Rigidbody2D>();
		deathTimer = GetComponent<Timer>();
		spawnTimer = GetComponent<Timer>();
		ballSpawn = Camera.main.GetComponent<BallSpawner>();
		GameObject hudGameObject = GameObject.FindGameObjectWithTag("HUD");
		hud = hudGameObject.GetComponent<HUD>();

		//spawnTimer.Duration = spawnTime;
		//spawnTimer.Run();

		Initialize();
		//if ()
		//{
		//	spawnTimer.Stop();
		//	Initialize();

		//	//this sets the death timer for our ball
		//	deathTimer.Duration = Lifetime;
		//	deathTimer.Run();
		//}

	}

	/// <summary>
	/// Determines the side the ball is on when it gets destroyed
	/// </summary>
	public void Update()
	{
		//this checks to see if our timer is finished
		//and destroys the ball if thats the case
		if (deathTimer.Finished)
		{
			ballSpawn.SpawnBall();
			Destroy(gameObject);
		}
	}
	
	/// <summary>
	/// setdirection method for the ball
	/// </summary>
	public void SetDirection(Vector2 direction)
	{
		//this gives us the new direction the ball is moving in while keeping the velocity the same
		rb2d.AddForce(direction * rb2d.velocity.normalized, ForceMode2D.Impulse);
	}
	/// <summary>
	/// onbecomeinvisible method to destroy ball
	/// </summary>
	private void OnBecameInvisible()
	{
		if (transform.position.x > ScreenUtils.ScreenRight || transform.position.x < ScreenUtils.ScreenLeft)
		{
			if (transform.position.x <= ScreenUtils.ScreenLeft)
			{
				screenSide = ScreenSide.Left;
			}
			else if (transform.position.x >= ScreenUtils.ScreenRight)
			{
				screenSide = ScreenSide.Right;
			}
			if (screenSide == ScreenSide.Left)
			{
				hud.AddPoints(screenSide, ConfigurationUtils.StandardBall);
			}
			else if (screenSide == ScreenSide.Right)
			{
				hud.AddPoints(screenSide, ConfigurationUtils.StandardBall);
			}
			deathTimer.Stop();
			//spawn in new ball and destroy old one
			ballSpawn.SpawnBall();
			Destroy(gameObject);
		}
	}
	/// <summary>
	/// This method will set the direction and speed of our ball
	/// </summary>
	public void Initialize()
	{
		//this decides whether our ball is going left or right
		int side = Random.Range(0, 2);
		if (side == 0)
		{
			//this calculates our angle if the ball is going to the left
			float angleLeft = Random.Range(135f * Mathf.Deg2Rad, 225f * Mathf.Deg2Rad);
			moveDirection = new Vector2(Mathf.Cos(angleLeft), Mathf.Sin(angleLeft));

			//adds force to the ball in that direction
			rb2d.AddForce(moveDirection * ConfigurationUtils.BallImpulseForce, ForceMode2D.Impulse);
		}

		if (side == 1)
		{
			//this calcs our angle if the ball is going to the right
			float angleRight = Random.Range(-45f * Mathf.Deg2Rad, 45f * Mathf.Deg2Rad);
			moveDirection = new Vector2(Mathf.Cos(angleRight), Mathf.Sin(angleRight));

			//add force to the ball in that direction
			rb2d.AddForce(moveDirection * ConfigurationUtils.BallImpulseForce, ForceMode2D.Impulse);
		}
	}
}
