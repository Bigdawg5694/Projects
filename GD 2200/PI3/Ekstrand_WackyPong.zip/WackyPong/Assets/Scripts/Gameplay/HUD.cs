using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class HUD : MonoBehaviour
{
	#region Fields

	//these are the tmp fields for hits
	[SerializeField]
    TextMeshProUGUI leftHits;

    [SerializeField]
    TextMeshProUGUI rightHits;

	[SerializeField]
	TextMeshProUGUI score;

	//these are fields for total hits and paddle scripts
	int leftHitCount;
	int rightHitCount;

	const string hitsPrefix = "Hits: ";

	int leftScore;
	int rightScore;

	const string scorePrefix = " - ";
	#endregion

	#region Methods

	/// <summary>
	/// This is to add a hit to the TMP hit counter on it's respective side
	/// </summary>
	/// <param name="side">the side the paddle is on</param>
	/// <param name="hits">the number of hits that gets added</param>
	public void AddHit(ScreenSide side, int hits)
	{
		if (side == ScreenSide.Left)
		{
			leftHitCount += hits;
			leftHits.text = hitsPrefix + leftHitCount;
		}
		if (side == ScreenSide.Right)
		{
			rightHitCount += hits;
			rightHits.text = hitsPrefix + rightHitCount;
		}
	}
	/// <summary>
	/// this will add the score based on the balls points
	/// </summary>
	/// 
	public void AddPoints(ScreenSide side, int hits)
	{
		if (side == ScreenSide.Left)
		{
			rightScore += hits;
			score.text = leftScore + scorePrefix + rightScore;
		}
		if (side == ScreenSide.Right)
		{
			leftScore += hits;
			score.text = leftScore + scorePrefix + rightScore;
		}
	}
	#endregion
}
