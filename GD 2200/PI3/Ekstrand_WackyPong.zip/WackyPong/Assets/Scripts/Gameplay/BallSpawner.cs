﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using static UnityEditor.FilePathAttribute;

/// <summary>
/// A ball spawner
/// </summary>
public class BallSpawner : MonoBehaviour
{
	[SerializeField]
	GameObject prefabBall;

	Vector2 location = Vector2.zero;
	

	/// <summary>
	/// Start is called before the first frame update
	/// </summary>
	void Start()
	{
		
	}
	
	/// <summary>
	/// Update is called once per frame
	/// </summary>
	void Update()
	{
		
	}

	/// <summary>
	/// Spawns a new ball, finds the ball scrpit attached, 
	/// and uses the Start method on it to tell the ball
	/// where to go and what direction to go
	/// </summary>
	public void SpawnBall()
	{
		//spawn ball at the location
		GameObject Ball = Instantiate(prefabBall, location, Quaternion.identity);

		//get the ball class
		Ball ballscript = prefabBall.GetComponent<Ball>();

		//run start method for ball
		ballscript.Start();
	}
}
